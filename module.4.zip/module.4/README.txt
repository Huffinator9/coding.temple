* Module 4 HTML & CSS Knowledge Check
** Components Implemented
   --0001. Form inside a <fieldset>
   --0010. Table
      --Bonus: Header
   --0011. Navigation Bar
   --0100. Multiple Images
      --Bonus: rounded corners
   --Bonus: Semantic styling and comprehensive layout
   --Bonus: stylesheet and personal image
